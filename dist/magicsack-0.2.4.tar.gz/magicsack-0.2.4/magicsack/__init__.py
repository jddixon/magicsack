# magicsack/__init__.py

__all__ = [ '__version__', '__version_date__',
          ]

__version__      = '0.2.4'
__version_date__ = '2015-05-15'

# OTHER EXPORTED CONSTANTS

